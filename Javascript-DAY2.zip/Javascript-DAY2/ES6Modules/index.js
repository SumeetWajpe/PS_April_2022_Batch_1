// import Addition, { Product } from "./module.js";
// console.log("The addition is : " + Addition(20, 30));
// console.log("The product is : " + Product(20, 30));

import * as MathModule from "./module.js";

console.log("The product is : " + MathModule.Product(20, 30));
