const express = require("express");
const app = express();
const port = 3000;
const path = require("path");
let courses = require("./models/course.model");

app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());
app.get("/", (req, res) => {
  //   res.send('<h1>Hello World!</h1>')
  //   res.json({ id: 1, title: "Laptop" });
  res.sendFile("Courses.html", { root: __dirname });
});
app.get("/courses", (req, res) => {
  // comes from db
  res.json(courses);
});

app.post("/newcourse", (req, res) => {
  let newCourse = req.body;
  courses = [...courses, newCourse];
  res.json({ msg: "success" });
});

app.delete("/courses/:id", (req, res) => {
  let theCourseId = req.params.id;
  // console.log(theCourseId);
  // delete from db
  courses = courses.filter((course) => course.id != theCourseId);
  console.log(courses);
  res.json({ msg: "success" });
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
